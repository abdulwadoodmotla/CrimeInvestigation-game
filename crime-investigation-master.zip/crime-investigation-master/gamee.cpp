
#include <iostream>

using namespace std;

void printf()
{ 
  std:: string SelectedFingerprint; //Declaration of the fingerprint that was selected
	std:: cin >> SelectedFingerprint; //Declaration of the right fingerprint of the muderer

	//Condition to check if the selected fingerprint matches the muderer fingerprints
	if (SelectedFingerprint == "Maria")
  { 
		 cout<<"You need for follow us to the Station for some questioning"<<endl;
		 cout<<"You win, Succesfully detected the muderer fingerprints"<<endl;
	}
	
	//Condition to check if the selected fingerprint doesn't match the muderer fingerprints
	else{
		cout<<"Wrong fingerprints recongnised, You lose!!"<<endl;
	}
};
int main ()
{
  printf();
	return 0;
}
